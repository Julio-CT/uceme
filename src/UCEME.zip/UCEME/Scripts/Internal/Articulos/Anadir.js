$(document).ready(function () {
    enableNavBar(4);
});
//# sourceMappingURL=Anadir.js.map