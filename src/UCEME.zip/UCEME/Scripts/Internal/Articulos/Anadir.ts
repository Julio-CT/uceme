﻿$(document).ready(() => {
    enableNavBar(4);
});