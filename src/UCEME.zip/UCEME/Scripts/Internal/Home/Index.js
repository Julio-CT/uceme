$(document).ready(function () {
    enableNavBar(1);
});
//# sourceMappingURL=Index.js.map