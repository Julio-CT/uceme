$(function () {
    $('.slider').slidesjs({
        width: 500,
        height: 284,
        navigation: false,
        play: {
            auto: true
        }
    });
});
//# sourceMappingURL=mostrarFotos.js.map