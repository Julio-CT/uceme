$(document).ready(() => {
    enableNavBar(1);
});
