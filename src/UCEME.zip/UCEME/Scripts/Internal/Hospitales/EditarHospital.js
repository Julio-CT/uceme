//$(document).ready(() => {
//    var idDatosPro = $('#datosPro').val();
//    var url = '/Hospitales/ListaCompanias';
//    url += '/?id=' + idDatosPro;
//    $.get(url, data => {
//        for (var i = 0; i < data.length; i++) {
//            var id = '#checks #' + data[i];
//            $(id).prop('checked', true);
//        }
//    });
//});
//# sourceMappingURL=EditarHospital.js.map