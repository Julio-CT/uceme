var manager = new ItemManager('ListaCitas');
$(document).ready(function () {
    enableNavBar(9);
});
//# sourceMappingURL=Index.js.map