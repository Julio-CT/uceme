var manager = new ItemManager('ListaCitas');

$(document).ready(() => {
    enableNavBar(9);
});
