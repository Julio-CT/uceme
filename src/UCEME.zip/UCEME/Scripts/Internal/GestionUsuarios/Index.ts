$(document).ready(() => {
    enableNavBar(10);
});
