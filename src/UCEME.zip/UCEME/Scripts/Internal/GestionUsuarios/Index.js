$(document).ready(function () {
    enableNavBar(10);
});
//# sourceMappingURL=Index.js.map