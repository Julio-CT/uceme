$(document).ready(() => {
    enableNavBar(5);
});
