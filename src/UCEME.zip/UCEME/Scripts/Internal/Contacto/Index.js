$(document).ready(function () {
    enableNavBar(5);
});
//# sourceMappingURL=Index.js.map