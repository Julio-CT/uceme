$(document).ready(() => {
    $(() => {
        $('#back').click(() => {
            history.go(-1);
        });
    });
});
