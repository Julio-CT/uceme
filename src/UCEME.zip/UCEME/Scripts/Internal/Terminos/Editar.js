$(document).ready(function () {
    $(function () {
        $('#back').click(function () {
            history.go(-1);
        });
    });
});
//# sourceMappingURL=Editar.js.map