function refrescar(page) {
    var url = '/' + page;
    window.location.href = url;
}
//# sourceMappingURL=RefreshPage.js.map