function refrescar(page: string) {
    var url = '/' + page;
  window.location.href = url;
}
