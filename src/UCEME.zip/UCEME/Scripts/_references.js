﻿/// <reference path="jquery-2.2.4.js" />
/// <reference path="jquery-ui-1.12.1.js" />
/// <reference path="modernizr-2.8.3.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
