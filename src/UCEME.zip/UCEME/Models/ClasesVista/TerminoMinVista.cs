﻿namespace Uceme.Model.Models.ClasesVista
{
    public class TerminoMinVista
    {
        public int IdTermino { get; set; }

        public string Nombre { get; set; }

        public string Textocorto { get; set; }
    }
}