﻿namespace Uceme.Model.Models.ClasesVista
{
    public class VideosVista
    {
        public string Titulo { get; set; }

        public string Descripcion { get; set; }

        public string Link { get; set; }

        public int IdVideo { get; set; }

        public int? Posicion { get; set; }
    }
}