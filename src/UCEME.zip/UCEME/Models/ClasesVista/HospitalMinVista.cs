﻿namespace Uceme.Model.Models.ClasesVista
{
    public class HospitalMinVista
    {
        public int IdDatosPro { get; set; }

        public string Nombre { get; set; }
    }
}