﻿namespace Uceme.Model.Models.ClasesVista
{
    public class DocumentosVista
    {
        public int IdDocumento { get; set; }

        public string Nombre { get; set; }

        public string Link { get; set; }

        public string Usuario { get; set; }

        public int Posicion { get; set; }
    }
}