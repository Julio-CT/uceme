﻿namespace Uceme.Model.Models.ClasesVista
{
    public class CompaniasVista
    {
        public int IdCompanias { get; set; }

        public string Nombre { get; set; }

        public string Foto { get; set; }

        public string Link { get; set; }

        public int Posicion { get; set; }
    }
}