﻿namespace Uceme.Model.Models.ClasesVista
{
    public class CompaniasSelectorVista
    {
        public int IdCompanias { get; set; }

        public string Nombre { get; set; }

        public bool Checked { get; set; }
    }
}