﻿namespace Uceme.Model.Models.ClasesVista
{
    public class MedicoMinVista
    {
        public int IdUsuario { get; set; }

        public string Nombre { get; set; }

        public string Apellidos { get; set; }

        public string Titulo { get; set; }

        public string Foto { get; set; }

        public int? Posicion { get; set; }
    }
}