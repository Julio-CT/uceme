﻿namespace Uceme.Model.Models.ClasesVista
{
    public class FotosVista
    {
        public int IdFoto { get; set; }

        public string Nombre { get; set; }

        public string Texto { get; set; }

        public bool? Destacada { get; set; }

        public int? Posicion { get; set; }
    }
}